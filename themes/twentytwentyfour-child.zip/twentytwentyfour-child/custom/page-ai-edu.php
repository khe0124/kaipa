<?php
/*
Template Name: AI Edu Page
*/

get_header(); ?>

<div id="ai-edu-page"></div>

<?php get_footer(); ?>
