<?php
/*
Template Name: CaseStudy Page
*/

get_header(); ?>

<div id="case-study-page"></div>
<div class="container mx-auto p-4"> 
    <?php the_content(); ?>
</div>
<?php get_footer(); ?>
