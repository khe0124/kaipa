<?php
/*
Template Name: AI Expert Page
*/

get_header(); ?>

<div id="ai-expert-page"></div>

<?php get_footer(); ?>
