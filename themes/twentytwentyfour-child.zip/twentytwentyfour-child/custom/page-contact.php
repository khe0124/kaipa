<?php
/*
Template Name: Contact Page
*/

get_header(); 

?>
<div id="contact-page" class="container mx-auto p-4"></div>
<?php
get_footer();
?>
