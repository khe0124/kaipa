<?php
/*
Template Name: AI Networking Page
*/

get_header(); ?>

<div id="ai-networking-page"></div>

<?php get_footer(); ?>
