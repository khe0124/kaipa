<?php
/*
Template Name: Blog Page
*/

get_header(); ?>

<div id="blog-page" />
<div class="container mx-auto p-4"> 
    <?php the_content(); ?>
</div>
<?php get_footer(); ?>
