<?php
/*
Template Name: Introduce Page
*/

get_header(); ?>

<div id="introduce-page"></div>

<?php get_footer(); ?>
