<?php
/*
Template Name: ExpertList Page
*/

get_header(); ?>

<div id="expert-list-page"></div>
<?php get_footer(); ?>
