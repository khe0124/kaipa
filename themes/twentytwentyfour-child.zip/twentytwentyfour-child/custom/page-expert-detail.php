<?php
/*
Template Name: ExpertDetail Page
*/

get_header(); ?>

<div id="expert-detail-page"></div>

<?php get_footer(); ?>
