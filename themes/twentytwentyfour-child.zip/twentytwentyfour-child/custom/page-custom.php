<?php
/*
Template Name: React Custom Page
*/

get_header(); 

?>
<div id="root" class="container mx-auto p-4"></div>
<?php
get_footer();
?>
